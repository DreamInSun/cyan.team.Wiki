<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Martin Michalek <michalek.dev@gmail.com>
 */
$lang['thumbnail_width']       = 'Šírka náhľadu';
$lang['thumbnail_height']      = 'Výška náhľadu';
$lang['image_width']           = 'Šírka obrázku';
$lang['image_height']          = 'Výška obrázku';
$lang['cols']                  = 'Počet obrázkov na riadok';
$lang['sort']                  = 'Spôsob triedenia obrázkov galérie';
$lang['sort_o_file']           = 'triedenie podľa mena';
$lang['sort_o_mod']            = 'triedenie podľa dátumu';
$lang['sort_o_date']           = 'triedenie podľa EXIF dátumu';
$lang['sort_o_title']          = 'triedenie podľa EXIF názvu';
$lang['options']               = 'Dodatočné imlicitné voľby galérie';
