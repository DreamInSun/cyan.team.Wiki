<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Martin Michalek <michalek.dev@gmail.com>
 */
$lang['pages']                 = 'Stránky galérie:';
$lang['js']['addgal']          = 'Pridaj menný priestor ako galériu';
