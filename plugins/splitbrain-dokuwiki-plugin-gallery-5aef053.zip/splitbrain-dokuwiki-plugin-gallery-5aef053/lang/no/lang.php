<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Daniel Raknes <rada@jbv.no>
 */
$lang['pages']                 = 'Bildesider:';
$lang['js']['addgal']          = 'Navnerom som bildearkiv';
