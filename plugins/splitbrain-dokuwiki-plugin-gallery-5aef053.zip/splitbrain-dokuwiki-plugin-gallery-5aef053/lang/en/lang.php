<?php

$lang['pages'] = 'Gallery Pages:';
$lang['js']['addgal'] = 'Add namespace as gallery';