<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Naveen Venugopal <naveen.venugopal.anu@gmail.com>
 */
$lang['pages']                 = 'பட தொகுப்பு பக்கங்கள் ';
$lang['js']['addgal']          = 'பட தொகுப்பை பெயர்வேளியாக சேர் ';
