<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Naveen Venugopal <naveen.venugopal.anu@gmail.com>
 */
$lang['thumbnail_width']       = 'சிறு படத்தின் உயரம்';
$lang['thumbnail_height']      = 'சிறு படத்தின் அகலம் ';
$lang['image_width']           = 'படத்தின் அகலம்';
$lang['image_height']          = 'படத்தின் உயரம்';
$lang['cols']                  = 'ஒரு வரிசையில் எத்தனை படங்கள் ';
$lang['sort']                  = 'இந்த பட தொகுப்பை எப்படி வகைப்படுத்துவது ';
$lang['sort_o_file']           = 'கோப்பின் பெயரை வைத்து வகைப்படுத்து ';
$lang['sort_o_mod']            = 'கோப்பின் தேதியை வைத்து வகைப்படுத்து ';
$lang['sort_o_date']           = 'EXIF தேதியை வைத்து வகைப்படுத்து';
$lang['sort_o_title']          = 'EXIF பெயரை வைத்து வகைப்படுத்து';
$lang['options']               = 'கூடுதல் படத் தொகுப்பின் முன்னிருப்பு விருப்பங்கள் ';
