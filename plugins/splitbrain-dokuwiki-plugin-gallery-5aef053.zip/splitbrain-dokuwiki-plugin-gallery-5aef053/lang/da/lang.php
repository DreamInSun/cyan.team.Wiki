<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Soren Birk <soer9648@hotmail.com>
 */
$lang['pages']                 = 'Gallerisider:';
$lang['js']['addgal']          = 'Tilføj navnerum som galleri';
