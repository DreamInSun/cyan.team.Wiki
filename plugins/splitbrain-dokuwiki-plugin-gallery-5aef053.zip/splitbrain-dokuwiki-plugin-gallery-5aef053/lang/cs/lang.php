<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Jaroslav Lichtblau <jlichtblau@seznam.cz>
 */
$lang['pages']                 = 'Stránky galerie:';
$lang['js']['addgal']          = 'Přidat jmenný prostor jako galerii';
