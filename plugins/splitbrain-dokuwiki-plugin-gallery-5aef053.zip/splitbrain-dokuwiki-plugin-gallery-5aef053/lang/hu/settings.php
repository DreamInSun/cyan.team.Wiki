<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author DelDadam <deldadam@gmail.com>
 */
$lang['thumbnail_width']       = 'Bélyegkép szélessége';
$lang['thumbnail_height']      = 'Bélyegkép magassága';
$lang['image_width']           = 'Képszélesség';
$lang['image_height']          = 'Képmagasság';
$lang['cols']                  = 'Képek száma soronként';
$lang['sort']                  = 'Galériaképek rendezése';
$lang['sort_o_file']           = 'Fájlok neve szerint';
$lang['sort_o_mod']            = 'Fájlok dátuma szerint';
$lang['sort_o_date']           = 'EXIF-dátum szerint';
$lang['sort_o_title']          = 'EXIF-cím szerint';
$lang['options']               = 'További alapértelmezett beállítások';
