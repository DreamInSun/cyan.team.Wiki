<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author DelDadam <deldadam@gmail.com>
 */
$lang['pages']                 = 'Képgaléria oldalai:';
$lang['js']['addgal']          = 'Névtér hozzáadása képgalériaként';
