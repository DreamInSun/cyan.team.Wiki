<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Joel Cantoral <cantoral.joel@gmail.com>
 * @author Domingo Redal <docxml@gmail.com>
 */
$lang['pages']                 = 'Páginas de Galería';
$lang['js']['addgal']          = 'Añadir espacio de nombres de galería';
