<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Christian "Na_kai" Sueur <sueur.christian@gmail.com>
 * @author NicolasFriedli <nicolas@theologique.ch>
 * @author Schplurtz le Déboulonné <schplurtz@laposte.net>
 */
$lang['pages']                 = 'Pages galerie:';
$lang['js']['addgal']          = 'Utiliser cette catégorie comme galerie';
