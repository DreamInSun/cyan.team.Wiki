<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author tsangho <ou4222@gmail.com>
 */
$lang['pages']                 = '相簿頁碼';
$lang['js']['addgal']          = '添加作為相簿的名字空間';
