<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Hugo Smet <hugo.smet@outlook.com>
 */
$lang['pages']                 = 'Beeldreeks pagina\'s:';
$lang['js']['addgal']          = 'Voeg naamruimte toe als beeldreeks';
