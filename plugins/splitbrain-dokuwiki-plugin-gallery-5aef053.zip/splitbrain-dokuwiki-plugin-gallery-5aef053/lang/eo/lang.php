<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Robert Bogenschneider <bogi@uea.org>
 */
$lang['pages']                 = 'Galeripaĝoj:';
$lang['js']['addgal']          = 'Aldoni nomspacon kiel galerio';
