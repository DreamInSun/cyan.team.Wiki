<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Nobuyuki Fukuyori <self@spumoni.org>
 */
$lang['pages']                 = 'ギャラリー・ページ';
$lang['js']['addgal']          = '名前空間の追加';
