<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Hideaki SAWADA <chuno@live.jp>
 */
$lang['thumbnail_width']       = 'サムネイル画像の幅';
$lang['thumbnail_height']      = 'サムネイル画像の高さ';
$lang['image_width']           = '画像の幅';
$lang['image_height']          = '画像の高さ';
$lang['cols']                  = '一行の画像数';
$lang['sort']                  = '画像のソート方法';
$lang['sort_o_file']           = 'ファイル名順';
$lang['sort_o_mod']            = 'ファイル日付順';
$lang['sort_o_date']           = 'EXIF日付順';
$lang['sort_o_title']          = 'EXIFタイトル順';
$lang['options']               = 'デフォルトに追加するギャラリーのオプション';
