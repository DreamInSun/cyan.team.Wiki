<?php
/**
 * Configuration for Javadoc plugin
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Stefan Rothe <info@stefan-rothe.ch>
 */

$meta['jdk']   = array('string');
$meta['user1'] = array('string');
$meta['user2'] = array('string');
$meta['user3'] = array('string');
$meta['user4'] = array('string');
$meta['user5'] = array('string');
$meta['show5'] = array('string');
$meta['show_icon']  = array('onoff');

