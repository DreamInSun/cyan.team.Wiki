<?php
/**
 * Translations for Javadoc plugin
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Stefan Rothe <info@stefan-rothe.ch>
 */

$lang['jdk'] = 'Javadoc base URL for JDK';
$lang['user1'] = 'Custom Javadoc base URL 1';
$lang['user2'] = 'Custom Javadoc base URL 2';
$lang['user3'] = 'Custom Javadoc base URL 3';
$lang['user4'] = 'Custom Javadoc base URL 4';
$lang['user5'] = 'Custom Javadoc base URL 5';

?>
