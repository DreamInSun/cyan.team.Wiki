<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Robert Bogenschneider <bogi@uea.org>
 */
$lang['noPrefix']              = 'Kiuj (komo-disigitaj) klasnomoj estu ekskludataj de la prefikso "wrap_"?';
$lang['restrictedClasses']     = 'limigi la uzon de la kromaĵo al tiuj klasoj (komo-disigitaj)';
$lang['restrictionType']       = 'tipo de limigo (ĉu la supre menciitaj klasoj estu inkludataj aŭ ekskludataj?)';
$lang['restrictionType_o_0']   = 'permesi ĉiujn klasojn krom la menciitaj';
$lang['restrictionType_o_1']   = 'limigi al nur tiuj grupoj, neniuj aliaj';
$lang['syntaxDiv']             = 'Kiun sintakson uzi por blok-volvoj en la ilaro-elektilo?';
$lang['syntaxSpan']            = 'Kiun sintakson uzi por enliniaj volvoj en la ilaro-elektilo?';
