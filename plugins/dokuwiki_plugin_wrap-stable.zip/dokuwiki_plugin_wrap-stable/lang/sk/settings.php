<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Martin Michalek <michalek.dev@gmail.com>
 */
$lang['noPrefix']              = 'Ktoré (čiarkou oddelené) mená tried by mali byť vynechané pri použití predpony "wrap_"?';
$lang['restrictedClasses']     = 'Obmedzenie použitia pluginu na tieto (čiarkou oddelené) triedy';
$lang['restrictionType']       = 'Typ obmedzenia, špecifikuje, či triedy uvedené vyššie maju byť zahrnuté alebo vynechané';
$lang['restrictionType_o_0']   = 'povolenie pre všetky triedy okrem uvedených vyššie';
$lang['restrictionType_o_1']   = 'obmedzenie len na triedy uvedené vyššie a žiadne iné';
