<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Edmondo <snarchio@gmail.com>
 * @author Giovanni <Giovanni.Garofalo@outlook.com>
 */
$lang['column']                = 'colonne';
$lang['em']                    = 'enfatizzato speciale';
$lang['hi']                    = 'evidenziato';
$lang['lo']                    = 'meno importante';
