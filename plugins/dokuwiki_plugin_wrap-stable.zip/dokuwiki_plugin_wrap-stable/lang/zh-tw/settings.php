<?php
/**
 * Traditional Chinese language file for config of Wrap plugin
 *
 */
$lang['noPrefix'] = '哪些CSS類別不需要加上"wrap_"前置詞？(逗號分隔)';
$lang['restrictedClasses'] = '下列的類別將套用使用限制(逗號分隔)';
$lang['restrictionType'] = '使用限制，指定上述的類別限制條件。';
  $lang['restrictionType_o_0'] = '允許所有類別。但上述的類別都被排除。';
  $lang['restrictionType_o_1'] = '只允許上述的類別。';

