<?php

$lang['picker']    = 'Wrap 插件';

$lang['column']    = '分欄';
$lang['box']       = '簡易置中方盒';
$lang['info']      = '「資訊」方盒';
$lang['tip']       = '「提示」方盒';
$lang['important'] = '「重要」方盒';
$lang['alert']     = '「警告」方盒';
$lang['help']      = '「協助」方盒';
$lang['download']  = '「下載」方盒';
$lang['todo']      = '「待辦」方盒';

$lang['clear']     = '清除浮動';

$lang['em']        = '特別強調';
$lang['hi']        = '醒目標記';
$lang['lo']        = '不重要';
