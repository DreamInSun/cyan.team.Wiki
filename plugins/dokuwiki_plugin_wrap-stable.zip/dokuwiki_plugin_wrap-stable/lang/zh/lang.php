<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 */
$lang['picker']                = 'Wrap 插件';
$lang['column']                = '分栏';
$lang['box']                   = '简单居中方框';
$lang['info']                  = '消息框';
$lang['tip']                   = '提示框';
$lang['important']             = '重要信息方框';
$lang['alert']                 = '警告框';
$lang['help']                  = '帮助框';
$lang['download']              = '下载框';
$lang['todo']                  = '待办事项方框';
$lang['clear']                 = '清除浮动';
$lang['em']                    = '特别强调';
$lang['hi']                    = '高亮';
$lang['lo']                    = '不重要';
