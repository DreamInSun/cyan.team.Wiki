<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author ilker R. Kapac <irifat@gmail.com>
 * @author İlker R. Kapaç <irifat@gmail.com>
 */
$lang['picker']                = 'Paket Eklentisi';
$lang['column']                = 'sütunlar';
$lang['box']                   = 'ortalanmış basit kutu';
$lang['info']                  = 'bilgi kutusu';
$lang['tip']                   = 'ipucu kutusu';
$lang['important']             = 'önemli kutusu';
$lang['alert']                 = 'ikaz kutusu';
$lang['help']                  = 'yardım kutusu';
$lang['download']              = 'indirme kutusu';
$lang['todo']                  = 'yapılacaklar kutusu';
$lang['clear']                 = 'boşlukları temizle';
$lang['em']                    = 'özellikle vurgulanmış';
$lang['hi']                    = 'vurgulanmış';
$lang['lo']                    = 'daha az önemli';
