<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Laynee <seedfloyd@gmail.com>
 * @author schplurtz <Schplurtz@laposte.net>
 * @author Schplurtz le Déboulonné <schplurtz@laposte.net>
 */
$lang['picker']                = 'Extension Wrap';
$lang['column']                = 'colonnes';
$lang['box']                   = 'bloc simple';
$lang['info']                  = 'bloc information';
$lang['tip']                   = 'bloc astuce';
$lang['important']             = 'bloc important';
$lang['alert']                 = 'bloc alerte';
$lang['help']                  = 'bloc aide';
$lang['download']              = 'bloc téléchargement';
$lang['todo']                  = 'bloc à faire';
$lang['clear']                 = 'rétablir le flux après un élément flottant';
$lang['em']                    = 'particulièrement important';
$lang['hi']                    = 'important';
$lang['lo']                    = 'peu important';
