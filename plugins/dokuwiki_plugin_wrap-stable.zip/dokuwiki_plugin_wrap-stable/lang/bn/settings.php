<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Ninetailz <ninetailz1125@gmail.com>
 */
$lang['noPrefix']              = 'যা (কমা দিয়ে পৃথক) শ্রেণীর নাম "wrap_" সঙ্গে অগ্রে যুক্ত হওয়া থেকে বাদ দেওয়া হবে?';
$lang['restrictedClasses']     = 'এইসব করতে প্লাগিন ব্যবহার সীমিত (কমা দিয়ে পৃথক করা) ক্লাস';
$lang['restrictionType']       = 'ক্লাস উপরে অন্তর্ভুক্ত বা বাদ দেওয়া হইবে যদি সীমাবদ্ধতা ধরন, নির্দিষ্ট করে';
$lang['restrictionType_o_0']   = 'উপরোক্ত জনকে ছাড়া সব শ্রেণীর অনুমতি';
$lang['restrictionType_o_1']   = 'শুধুমাত্র উপরোক্ত শ্রেণীর এবং কোন অন্যদের সীমিত';
$lang['syntaxDiv']             = 'কোন বাক্য গঠন ব্লক গোপন জন্য টুলবার জুতো ব্যবহার করা উচিত?';
$lang['syntaxSpan']            = 'কোন বাক্য গঠন ইনলাইন গোপন জন্য টুলবার জুতো ব্যবহার করা উচিত?';
