<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Ninetailz <ninetailz1125@gmail.com>
 */
$lang['picker']                = 'মোড়ানো প্লাগইন';
$lang['column']                = 'স্তম্ভ';
$lang['box']                   = 'সহজ কেন্দ্রিক বাক্স';
$lang['info']                  = 'তথ্য বাক্স';
$lang['tip']                   = 'টিপ বাক্স';
$lang['important']             = 'গুরুত্বপূর্ণ বাক্স';
$lang['alert']                 = 'সতর্কতা বাক্স';
$lang['help']                  = 'সাহায্য বাক্স';
$lang['download']              = 'ডাউনলোডের বাক্স';
$lang['todo']                  = 'করণীয় বাক্স';
$lang['clear']                 = 'স্পষ্ট floats';
$lang['em']                    = 'বিশেষ করে জোর';
$lang['hi']                    = 'হাইলাইট';
$lang['lo']                    = 'কম গুরুত্বপূর্ণ';
