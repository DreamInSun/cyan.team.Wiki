<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author reza_khn <reza_khn@yahoo.com>
 */
$lang['column']                = 'ستون';
$lang['box']                   = 'کادر ساده';
$lang['info']                  = 'کادر اطلاعات';
$lang['tip']                   = 'کادر نکته';
$lang['important']             = 'کادر مهم';
$lang['alert']                 = 'کادر هشدار';
$lang['help']                  = 'کادر کمک';
$lang['download']              = 'کادر دانلود';
$lang['todo']                  = 'کادر کاربردی';
$lang['clear']                 = 'کادر شناور فعال';
$lang['em']                    = 'تاکید';
$lang['hi']                    = 'هایلایت';
$lang['lo']                    = 'کم اهمیت';
