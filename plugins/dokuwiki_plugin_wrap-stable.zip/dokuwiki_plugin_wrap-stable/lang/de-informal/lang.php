<?php

$lang['picker']    = 'Wrap-Plugin';

$lang['column']    = 'Spalten';
$lang['box']       = 'einfache zentrierte Box';
$lang['info']      = 'Info-Box';
$lang['tip']       = 'Tip-Box';
$lang['important'] = 'Wichtig-Box';
$lang['alert']     = 'Warn-Box';
$lang['help']      = 'Hilfe-Box';
$lang['download']  = 'Download-Box';
$lang['todo']      = 'Zu-Erledigen-Box';

$lang['clear']     = 'Floats beseitigen';

$lang['em']        = 'wichtig';
$lang['hi']        = 'markieren';
$lang['lo']        = 'weniger wichtig';
