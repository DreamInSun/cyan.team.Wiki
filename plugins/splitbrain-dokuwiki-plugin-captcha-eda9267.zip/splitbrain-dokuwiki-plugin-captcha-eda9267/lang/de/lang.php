<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Andreas Gohr <andi@splitbrain.org>
 */
$lang['testfailed']            = 'Das CAPTCHA wurde nicht korrekt beantwortet.';
$lang['fillcaptcha']           = 'Bitte übertragen Sie die Buchstaben in das Eingabefeld.';
$lang['fillmath']              = 'Bitte lösen Sie folgende Gleichung:';
$lang['soundlink']             = 'Wenn Sie die Buchstaben auf dem Bild nicht lesen können, laden Sie diese .wav Datei herunter, um sie vorgelesen zu bekommen.';
$lang['honeypot']              = 'Dieses Feld bitte leer lassen';
