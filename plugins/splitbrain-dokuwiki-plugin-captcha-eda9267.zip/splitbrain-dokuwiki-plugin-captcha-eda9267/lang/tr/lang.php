<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Ozan Hacibekiroglu <ozan_haci@yahoo.com>
 */
$lang['testfailed']            = 'Üzgünüz, CAPTCHA doğru cevaplanmadı. Belki bir insan değilsiniz (bot\'sunuz)?';
$lang['fillcaptcha']           = 'İnsan olduğunuzu kanıtlamak için lütfen bütün harfleri kutuya giriniz.';
$lang['fillmath']              = 'Lütfen şu eşitliği çözünüz ki insan olduğunuzu ispatlayınız.';
$lang['soundlink']             = 'Eğer resimdeki harfleri okuyamıyorsanız, bu .wav dosyasını size okuması için indiriniz.';
$lang['honeypot']              = 'Lütfen bu alanı boş bırakınız: ';
