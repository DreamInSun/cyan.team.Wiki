<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Þór Sigurðsson <thor@orku.net>
 */
$lang['testfailed']            = 'Því miður, en staðfestingarkóðanum var ekki rétt svarað. Kannski ertu ekki mennsk(ur) þrátt fyrir allt?';
$lang['fillcaptcha']           = 'Vinsamlegast ritaðu alla stafina inn í reitinn til að sanna að þú sért manneskja.';
$lang['fillmath']              = 'Vinsamlegast leystu eftirfarandi jöfnu til að sanna að þú sért manneskja.';
$lang['soundlink']             = 'Ef þú getur ekki lesið stafina á myndinni, sæktu þá þessa .wav skrá til að fá stafina lesna fyrir þig.';
$lang['honeypot']              = 'Vinsamlegast skildu þennan reit eftir auðan:';
