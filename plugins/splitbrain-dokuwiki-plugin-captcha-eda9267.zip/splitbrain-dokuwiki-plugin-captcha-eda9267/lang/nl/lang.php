<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Ruben Schouten <mail@ruben.cc>
 * @author Mark C. Prins <mprins@users.sf.net>
 * @author Mark Prins <mprins@users.sf.net>
 */
$lang['testfailed']            = 'Sorry, maar de CAPTCHA is onjuist beantwoord. Misschien ben je toch geen mens?';
$lang['fillcaptcha']           = 'Tik de letters in het onderstaande vakje over om aan te tonen dat je een mens bent.';
$lang['fillmath']              = 'Geef antwoord op de rekensom om aan te tonen dat je een mens bent.';
$lang['soundlink']             = 'Als je de letters in de afbeelding niet kunt lezen kun je dit .wav bestand downloaden om ze te laten voorlezen.';
$lang['honeypot']              = 'Dit veld leeg laten';
