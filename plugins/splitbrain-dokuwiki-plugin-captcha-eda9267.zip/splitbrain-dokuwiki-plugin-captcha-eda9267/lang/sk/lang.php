<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Jozef Riha <jose1711@gmail.com>
 * @author Martin Michalek <michalek.dev@gmail.com>
 */
$lang['testfailed']            = 'Ľutujem, ale na CAPTCHA nebolo odpovedané správne. Je možné, že by ste vôbec neboli človekom?';
$lang['fillcaptcha']           = 'Vyplňte prosím všetky písmená v poli, aby ste dokázali, že nie ste skript.';
$lang['fillmath']              = 'Prosím vyriešte nasledujúcu rovnicu, aby sme vás odlíšili od automatických web nástrojov.';
$lang['soundlink']             = 'Ak nedokážete prečítať písmená na obrázku, stiahnite si tento .wav súbor a text vám prečítame.';
$lang['honeypot']              = 'Prosím nechajte toto pole prázdne:';
