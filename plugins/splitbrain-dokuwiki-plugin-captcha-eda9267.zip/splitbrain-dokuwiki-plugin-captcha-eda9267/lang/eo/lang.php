<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Tradukis Ljosxa Kuznecov <ka2pink@gmail.com>
 * @author Robert Bogenschneider <bogi@uea.org>
 */
$lang['testfailed']            = 'Pardonon, sed CAPTCHA ne respondis korekte. Eble vi tute ne estas homo, ĉu?';
$lang['fillcaptcha']           = 'Bonvolu tajpi ĉiujn literojn en la kampeton, por pruvi ke vi estas homo.';
$lang['fillmath']              = 'Bonvolu solvi sekvan ekvacion por pruvi, ke vi estas homa.';
$lang['soundlink']             = 'Se vi ne povas legi la literojn en la bildo, ŝarĝu tiun .wav-dosieron por aŭdi ilin.';
$lang['honeypot']              = 'Bonvolu lasi tiun kampon malplena:';
