<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author alhajr <alhajr300@gmail.com>
 */
$lang['testfailed']            = 'عذراً، لكن لم يكن الرد على كلمة التحقق بشكل صحيح.';
$lang['fillcaptcha']           = 'الرجاء تعبئة كافة الأحرف في المربع.';
$lang['fillmath']              = 'الرجاء حل المعادلة التالية.';
$lang['soundlink']             = 'إذا كنت لا تستطيع قراءة الحروف على الصورة، تحميل ملف الصوت يساعدك على قراءة الأحرف.';
$lang['honeypot']              = 'الرجاء الحفاظ على هذا الحقل فارغاً:';
