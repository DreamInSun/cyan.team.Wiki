<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Pål Julius Skogholt <pal.julius@skogholt.org>
 */
$lang['testfailed']            = 'Lei for det, men CAPTHCA-svaret ditt var ikkje korrekt. Er du kanskje ikkje eit menneske likevel?';
$lang['fillcaptcha']           = 'Gjer vel og fyll inn alle bokstavane i boksen for å bevise at du er eit menenske.';
$lang['fillmath']              = 'Gjer vel og løys denne likninga for å bevise at du er menneske';
$lang['soundlink']             = 'Dersom du ikkje kan lese bokstavane i bildet, last ned .wav-fila for å få dei opplest';
$lang['honeypot']              = 'Hald dette feltet tomt';
