<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author soer9648 <soer9648@eucl.dk>
 */
$lang['testfailed']            = 'Desværre, CAPTCHA blev ikke besvaret korrekt. Du er muligvis ikke et menneske?';
$lang['fillcaptcha']           = 'Skriv venligst alle bogstaverne i boksen for at bevise at du er et menneske.';
$lang['fillmath']              = 'Løs venligst følgende ligning for at bevise at du er et menneske.';
$lang['soundlink']             = 'Hvis du ikke kan læse bogstaverne på skærmen, kan du downloade denne .wav-fil, for at få dem læst op.';
$lang['honeypot']              = 'Hold venligst dette felt tomt:';
