<?php
/**
 * Portuguese language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Flávio Roberto Santos <flavio.barata@gmail.com>
 * @author     Marcus D'Alencar <marcus_dalencar@yahoo.com.br>
 */
 
// for the configuration manager
$lang['size']   = 'tamanho padrão do avatar';
$lang['rating'] = 'rating mínimo para os gravatars';

//Setup VIM: ex: et ts=2 enc=utf-8 :
