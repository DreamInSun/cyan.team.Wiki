<?php
/**
 * Traditional Chinese language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Jonathan Tsai <tryweb@ichiay.com>
 */
 
// for the configuration manager
$lang['size']   = '預設 avatar 圖像大小';
$lang['rating'] = '最低 gravatars 的圖像分級';

//Setup VIM: ex: et ts=2 enc=utf-8 :