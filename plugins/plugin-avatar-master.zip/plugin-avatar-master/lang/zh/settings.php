<?php
/**
 * Chinese Simplified language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     ZDYX <zhangduyixiong@gmail.com>
 */
 
// for the configuration manager
$lang['size']   = '默认的 Avatar 头像大小';
$lang['rating'] = '默认的 Gravatar 头像评级';

//Setup VIM: ex: et ts=2 enc=utf-8 :