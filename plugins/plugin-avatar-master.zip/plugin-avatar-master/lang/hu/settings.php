<?php
/**
 * Hungarian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Norbert Csík <norbert.csik@gmail.com>
 */
 
// for the configuration manager
$lang['size']   = 'a avatar kép alapértelmezett mérete';
$lang['rating'] = 'minimum osztályzat a gravatorokhoz';

//Setup VIM: ex: et ts=2 enc=utf-8 :