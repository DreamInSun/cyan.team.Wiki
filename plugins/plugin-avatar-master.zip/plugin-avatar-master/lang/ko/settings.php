<?php
/**
 * Korean language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Myeongjin <aranet100@gmail.com>
 */
 
// for the configuration manager
$lang['namespace'] = '로컬 아바타에 대한 이름공간';
$lang['size']      = '아바타의 기본 크기';
$lang['rating']    = 'gravatar에 대한 최소 평가';

//Setup VIM: ex: et ts=2 enc=utf-8 :
