<?php
/**
 * English language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Esther Brunner <wikidesign@gmail.com>
 */
 
// for the configuration manager
$lang['namespace'] = 'namespace for local avatars';
$lang['size']      = 'default size of avatar';
$lang['rating']    = 'minimum rating for gravatars';

//Setup VIM: ex: et ts=2 enc=utf-8 :