<?php
/**
 * Slovak language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Pirhala Marek <mpirhala@genesispo.sk>
 */
 
// for the configuration manager
$lang['size']   = 'implicitná veľkosť avataru';
$lang['rating'] = 'minimálne hodnotenie gravataru';

//Setup VIM: ex: et ts=2 enc=utf-8 :
