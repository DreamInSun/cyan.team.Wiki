<?php
/**
 * Dutch language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Erwin Moller <erwin@darwine.nl>
 */

// for the configuration manager
$lang['size']   = 'standaard afbeeldinggrootte van de avatars';
$lang['rating'] = 'minimale rating voor de gravatars';

//Setup VIM: ex: et ts=2 enc=utf-8 :