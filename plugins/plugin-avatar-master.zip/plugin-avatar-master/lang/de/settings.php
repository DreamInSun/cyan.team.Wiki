<?php
/**
 * German language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Esther Brunner <wikidesign@gmail.com>
 */

// for the configuration manager
$lang['namespace'] = 'Namensraum für lokale Avatare';
$lang['size']      = 'Standard-Grösse für Avatare';
$lang['rating']    = 'Min. Einstufung von Gravataren';

//Setup VIM: ex: et ts=2 enc=utf-8 :