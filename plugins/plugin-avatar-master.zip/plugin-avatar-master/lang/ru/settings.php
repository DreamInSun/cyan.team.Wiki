<?php
/**
 * Russian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Mike Lykov <lykov.myu@mgsm.ru>
 */
 
// for the configuration manager
$lang['size']   = 'Размер avatar по умолчанию';
$lang['rating'] = 'Минимальный рейтинг для gravatar-ов';

//Setup VIM: ex: et ts=2 enc=utf-8 :