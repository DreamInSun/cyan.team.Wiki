<?php
/**
 * Spanish language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Jos Antonio Fuentes Santiago <joanfusan@hotmail.com>
 */
 
// para el administrador de configuraión
$lang['size']    = 'tamaño predeterminado para el avatar';
$lang['rating']  = 'puntuación mínima para elegir gravatars';

//Setup VIM: ex: et ts=2 enc=utf-8 :