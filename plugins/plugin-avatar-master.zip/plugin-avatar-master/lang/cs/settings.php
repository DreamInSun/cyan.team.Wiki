<?php
/**
 * Czech language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Esther Brunner <wikidesign@gmail.com>
 */
 
// for the configuration manager
$lang['size']   = 'implicitní velikost avataru';
$lang['rating'] = 'minimální hodnocení gravataru';

//Setup VIM: ex: et ts=2 enc=utf-8 :
