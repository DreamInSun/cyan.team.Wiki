<?php
/**
 * Polish language file v0.9 by Zbyszekk <zbypan@gmail.com>
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Esther Brunner <wikidesign@gmail.com> (in English)
 */
 
// for the configuration manager
$lang['size']   = 'Domyślny rozmiar avatar\'a';

//Setup VIM: ex: et ts=2 enc=utf-8 :