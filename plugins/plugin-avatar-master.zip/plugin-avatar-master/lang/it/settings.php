<?php
/**
 * Italian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Fabio Asnicar <fabio.asnicar@gmail.com>
 */

// for the configuration manager
$lang['size']   = 'Dimensione di default del avatar';
$lang['rating'] = 'Valutazione minima per i gravatar';

//Setup VIM: ex: et ts=2 enc=utf-8 :