<?php
/**
 * Default settings for the fontawesome plugin
 *
 * @author Mikhail Medvedev <mmedvede@cs.uml.edu>
 */

//$conf['fixme']    = 'FIXME';
