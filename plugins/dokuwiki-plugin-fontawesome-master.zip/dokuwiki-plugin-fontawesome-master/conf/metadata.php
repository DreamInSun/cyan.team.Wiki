<?php
/**
 * Options for the fontawesome plugin
 *
 * @author Mikhail Medvedev <mmedvede@cs.uml.edu>
 */


//$meta['fixme'] = array('string');

