<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author HL <tohelong@gmail.com>
 */
$lang['menu']                  = 'SQLite的接口';
$lang['db']                    = '数据库';
$lang['index']                 = '列表索引';
$lang['rename2to3']            = '更改sqlite后缀为 sqlite3';
$lang['convert2to3']           = ' Sqlite2 转 Sqlite3格式';
