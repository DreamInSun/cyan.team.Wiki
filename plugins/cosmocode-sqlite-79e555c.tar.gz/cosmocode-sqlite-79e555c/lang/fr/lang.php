<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Emmanuel Dupin <seedfloyd@gmail.com>
 * @author Nicolas Friedli <nicolas@theologique.ch>
 */
$lang['menu']                  = 'Interface SQLite';
$lang['db']                    = 'Base de données';
$lang['index']                 = 'afficher les index';
$lang['table']                 = 'afficher les tables';
$lang['rename2to3']            = 'Renommer %s.sqlite en *.sqlite3';
$lang['convert2to3']           = 'Convertir %s du format Sqlite2 au format Sqlite3';
