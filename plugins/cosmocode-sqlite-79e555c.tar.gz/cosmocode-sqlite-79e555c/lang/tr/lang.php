<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author İlker R. Kapaç <irifat@gmail.com>
 */
$lang['menu']                  = 'SQLite Arayüzü';
$lang['db']                    = 'Veritabanı';
$lang['index']                 = 'dizinleri listele';
$lang['table']                 = 'tabloları listele';
$lang['rename2to3']            = '%s.sqlite dosyasını *.sqlite3 olarak yeniden adlandır';
$lang['convert2to3']           = '%s veritabanını Sqlite2\'den Sqlite3 biçimine dönüştür';
