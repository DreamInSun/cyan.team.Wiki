<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Janar Leas <janarleas@gmail.com>
 */
$lang['menu']                  = 'SQLite liides';
$lang['db']                    = 'Andmebaas';
$lang['index']                 = 'järjesta võtmed';
$lang['table']                 = 'järjesta tabelid';
$lang['rename2to3']            = 'Nimeta %s.sqlite ümber *.sqlite3-ks';
$lang['convert2to3']           = 'Teisenda %s Sqlite2 vormingust ümber Sqlite3 vormingusse';
