<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Robert Bogenschneider <bogi@uea.org>
 */
$lang['menu']                  = 'SQLite-interfaco';
$lang['db']                    = 'Datumbazo';
$lang['index']                 = 'listigi indeksojn';
$lang['table']                 = 'listigi tabelojn';
$lang['rename2to3']            = 'Renomi %s.sqlite al *.sqlite3';
$lang['convert2to3']           = 'Konverti %s de Sqlite2 al Sqlite3-formato';
