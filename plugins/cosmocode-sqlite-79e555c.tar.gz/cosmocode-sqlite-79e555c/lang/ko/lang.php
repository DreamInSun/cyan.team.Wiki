<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Myeongjin <aranet100@gmail.com>
 */
$lang['menu']                  = 'SQLite 인터페이스';
$lang['db']                    = '데이터베이스';
$lang['index']                 = '색인 나열';
$lang['table']                 = '테이블 나열';
$lang['rename2to3']            = '%s.sqlite에서 *.sqlite3로 이름 바꾸기';
$lang['convert2to3']           = '%s(을)를 Sqlite2 형식에서 Sqlite3 형식으로 변환';
