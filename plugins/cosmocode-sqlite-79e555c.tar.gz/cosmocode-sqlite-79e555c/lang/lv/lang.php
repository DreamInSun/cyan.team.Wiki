<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Jānis-Marks Gailis <jm-gailis@fai-vianet.fr>
 */
$lang['db']                    = 'Datubāze';
