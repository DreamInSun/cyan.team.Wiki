<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author     Aleksandr Selivanov <alexgearbox@gmail.com>
 * @author Aleksandr Selivanov <alexgearbox@gmail.com>
 */
$lang['menu']                  = 'Интерфейс SQLite';
$lang['db']                    = 'База данных';
$lang['index']                 = 'list indexes';
$lang['table']                 = 'list tables';
$lang['rename2to3']            = 'Переименовать %s.sqlite в *.sqlite3';
$lang['convert2to3']           = 'Конвертировать %s из формата Sqlite2 в Sqlite3';
