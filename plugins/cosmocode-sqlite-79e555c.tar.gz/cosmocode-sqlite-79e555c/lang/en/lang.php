<?php

$lang['menu'] = 'SQLite Interface';
$lang['db']   = 'Database';

$lang['index'] = 'list indexes';
$lang['table'] = 'list tables';

$lang['rename2to3']  = 'Rename %s.sqlite to *.sqlite3';
$lang['convert2to3'] = 'Convert %s from Sqlite2 to Sqlite3 format';
