<?php
/**
* DokuWiki always renders the full template, making it impossible to load just tpl_content
* without a custom template. This amazing template renders nothing!
*/
