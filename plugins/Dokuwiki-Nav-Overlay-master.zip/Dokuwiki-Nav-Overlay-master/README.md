# Dokuwiki-Nav-Overlay
Creates a window at the template level that can be opened and closed into which navigation plugins or any other data  can be inserted

Plase see the plugin page at dkuwiki.org for complete instructions. https://www.dokuwiki.org/plugin:overlay


