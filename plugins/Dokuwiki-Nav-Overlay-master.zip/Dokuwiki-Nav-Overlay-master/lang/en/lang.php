<?php
$lang['toggle_name'] = 'Index';
$lang['close'] = 'Close';