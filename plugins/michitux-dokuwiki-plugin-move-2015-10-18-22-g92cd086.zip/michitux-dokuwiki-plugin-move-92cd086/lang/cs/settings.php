<?php
/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Pavel Kochman
 */

$lang['allowrename'] = 'Povolit přeijmenovat stránky témto skupinám a uživatelům (oddělených čárkou).';
$lang['minor']       = 'Označit úpravu odkaů jako drobná změna? Drobné změny nebudou viditelné v RSS feeds a v odebíraných mailech změn.';
$lang['autoskip']    = 'Zapnout automatické přeskakování chyb při přesouvání namespace.';
$lang['autorewrite'] = 'Zapnout automatické přepisování odkazů po přesunutí namespace.';
