<?php

$lang['allowrename'] = 'Allow renaming of pages to these groups and users (comma separated).';
$lang['minor']       = 'Mark link adjustments as minor? Minor changes will not be listed in RSS feeds and subscription mails.';
$lang['autoskip']    = 'Enable automatic skipping of errors in namespace moves by default.';
$lang['autorewrite'] = 'Enable automatic link rewriting after namespace moves by default.';
