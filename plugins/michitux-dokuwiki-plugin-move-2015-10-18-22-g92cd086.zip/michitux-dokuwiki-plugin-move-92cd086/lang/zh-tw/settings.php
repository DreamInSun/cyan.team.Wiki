<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Aaron Wang <edb030@163.come>  */

$lang['allowrename']           = '允許這些用戶/用戶群組重命名頁面（用逗號分隔）';
$lang['minor']                 = '將鏈接修正標記為『細微變動』，這樣就不會被列入RSS訂閱或訂閱郵件中。';
$lang['autoskip']              = '目錄移動時，啟用預設自動跳過錯誤';
$lang['autorewrite']           = '目錄移動時，啟用預設自動修正鏈接';
