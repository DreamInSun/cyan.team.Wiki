<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Hanjia Zhuang <shzhuanghanjia@163.com>
 */
$lang['allowrename']           = '允许这些用户/用户组重命名页面（用逗号分隔）';
$lang['minor']                 = '将链接修正标记为”细微变动“，这样就不会被列入RSS订阅或订阅邮件中。';
$lang['autoskip']              = '在目录移动中，启用默认自动跳过错误';
$lang['autorewrite']           = '在目录移动中，启用默认自动修正链接';
