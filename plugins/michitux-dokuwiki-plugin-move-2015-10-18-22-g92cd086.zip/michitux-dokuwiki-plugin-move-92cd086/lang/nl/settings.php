<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Peter van Diest <peter.van.diest@xs4all.nl>
 */
$lang['allowrename']           = 'Hernoemen van pagina\'s toestaan voor deze groepen en gebruikers (komma-gescheiden).';
$lang['minor']                 = 'Link-aanpassingen als kleine aanpassingen markeren? Kleine aanpassingen worden niet genoemd in RRS feeds en nieuwsbrieven.';
$lang['autoskip']              = 'Automatisch overslaan van fouten bij verplaatsingen van namespaces standaard inschakelen.';
$lang['autorewrite']           = 'Automatisch herschrijven van links na verplaatsingen van namespaces standaard inschakelen.';
