<?php

$conf['allowrename'] = '@user';
$conf['minor'] = 1;
$conf['autoskip'] = 0;
$conf['autorewrite'] = 1;
