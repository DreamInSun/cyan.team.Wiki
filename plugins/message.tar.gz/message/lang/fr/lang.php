<?php
$lang['menu']                  = 'Messages d\'information';

$lang['mess_texte']            = 'Utilisez les champs ci-dessous pour ins&eacute;rer vos messages.<br />Une fois vos messages sauvegard&eacute;s, ils seront <b>imm&eacute;diatement visibles par tous les utilisateurs</b>.';
$lang['mess_titre']            = 'Gestion des messages d\'information';
$lang['mess_err']              = 'Message d\'erreur';
$lang['mess_info']             = 'Message d\'information';
$lang['mess_ok']               = 'Message de validation';
$lang['mess_rappel']           = 'Message de rappel';
$lang['mess_sauver']           = 'Sauvegarder';
$lang['mess_err_ouvrir']       = 'Impossible d\'ouvrir le fichier';
$lang['mess_err_ecrire']       = 'Impossible d\'&eacute;crire dans le fichier';
$lang['mess_err_lectureseule'] = 'Le fichier n\'est pas accessible en &eacute;criture';
$lang['mess_erreurs']          = 'Au moins une erreur s\'est produite pendant la sauvegarde des messages.';
