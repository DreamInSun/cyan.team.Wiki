<?php
$lang['menu']                  = 'Information messages';

$lang['mess_texte']            = 'Use the form below to insert your messages.<br />Your messages are visible <b>by all users as soon as they are saved</b>.';
$lang['mess_titre']            = 'Information messages administration';
$lang['mess_err']              = 'Error message';
$lang['mess_info']             = 'Information message';
$lang['mess_ok']               = 'Confirmation message';
$lang['mess_rappel']           = 'Remind message';
$lang['mess_sauver']           = 'Save';
$lang['mess_err_ouvrir']       = 'Unable to open the file';
$lang['mess_err_ecrire']       = 'Unable to write the file';
$lang['mess_err_lectureseule'] = 'The file is not writable';
$lang['mess_erreurs']          = 'At least one error occured while saving the messages.';
