CREATE TABLE calendarsettings (
    id integer primary key asc,
    key text,
    value text,
    userid text
);
