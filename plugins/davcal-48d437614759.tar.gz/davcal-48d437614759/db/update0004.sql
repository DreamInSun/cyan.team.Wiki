CREATE TABLE calendartoprivateurlmapping (
    id integer primary key asc,
    url text,
    calid integer
);
