CREATE TABLE pagetocalendarmapping (
    id integer primary key asc,
    page text,
    calid integer
);
