<?php
/**
 * Korean language file for oauth plugin
 *
 * @author SC Yoo <dryoo@Live.com>
 */

$lang['emailduplicate'] = '이 메일주소는 이미 다른 사용자와 연결되어 있습니다.';
$lang['loginwith']      = '다른 서비스로 로그인합니다:';
$lang['authnotenabled'] = '해당 이메일에 연결된 계정은 %s 서비스로 로그인할 수 있도록 설정되어 있지 않습니다. 다른 방법으로 로그인하시고 설정에서 해당 서비스로 로그인이 가능하도록 변경하여주세요.';
